#pragma once

extern void SetupWindow();
extern void ResetWindow();
