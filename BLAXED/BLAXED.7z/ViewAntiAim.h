#pragma once


void ViewAntiAim(ClientFrameStage_t Stage, int step);
