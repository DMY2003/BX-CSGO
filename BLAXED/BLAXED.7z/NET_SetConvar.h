#pragma once

void NET_SetConVar(const char* name, const char* value);

void SetClanTag(const char *tag);
void SetName(const char *name);
