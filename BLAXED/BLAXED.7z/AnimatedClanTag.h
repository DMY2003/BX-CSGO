﻿#pragma once

class AnimatedClanTag
{
public:
	void Tick();
};

extern AnimatedClanTag *animatedClanTag;
