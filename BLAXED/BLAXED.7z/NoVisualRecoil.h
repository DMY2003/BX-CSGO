#pragma once

void NoVisualRecoil(ClientFrameStage_t Stage, int step);
