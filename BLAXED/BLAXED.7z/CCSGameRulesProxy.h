
class CSGameRules
{
public:
	bool m_bIsValveDS;
	bool m_bFreezePeriod;
}
;
